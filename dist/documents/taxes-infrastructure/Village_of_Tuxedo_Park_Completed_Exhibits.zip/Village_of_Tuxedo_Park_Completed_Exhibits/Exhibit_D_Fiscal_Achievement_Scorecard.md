# Exhibit D: Fiscal Achievement Scorecard

**Prepared for:** Memorandum to the Village Board of Tuxedo Park  
**Record period:** McFadden administration, July 2017–2023, with later authorizations shown for succession context

## Executive finding

The documented record supports the conclusion that fiscal restraint and infrastructure planning occurred together. During the McFadden administration, the Village received a 1.7 OSC fiscal-stress score for 2022, S&P raised the general-obligation rating from AA- to AA/Stable in July 2021, and the Village reported in May 2023 that the 2022–23 budget was projected to finish 6.51% under budget and that the 2023–24 property-tax levy would decline 1.7621% without use of unallocated surplus.

## Fiscal scorecard

| Measure | Documented result | Benchmark | Meaning |
|---|---:|---:|---|
| First-administration tax restraint | According to Deputy Mayor and Treasurer Christopher Hansen, the Village adopted what he described as its lowest tax increase in the preceding 15 years | Hansen statement, paraphrased by McFadden | Attributed achievement, not an independently recalculated 15-year series |
| FY2022 OSC fiscal-stress score | 1.7 | 25.0 first designation threshold | No Designation; 23.3 points below the first threshold |
| General-obligation credit rating | AA/Stable in July 2021 | Upgrade from AA- | Independent improvement in credit profile |
| FY2022–23 projected budget result | 6.51% under budget | Adopted budget | Village-reported favorable variance |
| FY2023–24 property-tax levy | 1.7621% reduction | Prior-year levy | Tax restraint at the end of the administration |
| Use of unallocated surplus in FY2023–24 budget | None reported | Village budget statement | Levy reduction was not reported as funded by unallocated surplus |
| FY2024 tax-cap position | $3,654,610 levy | $3,920,740 limit | $266,130 below the reported cap |
| FY2024 constitutional tax-limit use | $3,654,610 levy | $9,061,694 limit | Approximately 40.3% used |

## Capital authorizations

| Program | Maximum authorization | Date and attribution | Financial meaning |
|---|---:|---|---|
| Water-system improvements | $4,500,000 | March 10, 2025; Citrin Board | Financing ceiling, not proof of issuance or expenditure |
| Sewer-system improvements | $650,000 | March 3, 2025; Citrin Board | Financing ceiling |
| Pond No. 3 bridge replacement | $250,000 | March 3, 2025; Citrin Board | Financing ceiling; separate from dam and sewer work |
| **Total** | **$5,400,000** | **Successor Board** | **Not McFadden-era spending** |

## Capital delivery and cost control

| Measure | Documented result | Assessment |
|---|---|---|
| Engineer-led capital plan | Nine coordinated project tracks documented in December 2022 | Active capital program at transition |
| Trunk-sewer investigation | Approximately $49,520 invoiced against $91,600 budget | Approximately 46% below budget |
| SSES rehabilitation | Work in six road areas with EFC grant and financing | Construction and outside funding documented |
| Water-system readiness | Tuxedo Lake design nearing completion; Mountain Road-area field investigation underway | Later water financing continued an existing project pipeline |
| Surplus-equipment disposal | $8,545 received from 10 of 11 auctioned DPW items by April 2022 | Documented asset recovery |

## Procurement comparison

| Measure | 2018 audited period | Later corrective record |
|---|---|---|
| Professional-service competition | 14 of 15 providers; $926,188 paid without solicited competition | Proposal and interview process described; later files contain formal scopes and proposals |
| Written agreements | Five providers; $169,330 paid without written agreements | Later engineering records contain scopes, fees, amendments, and acceptance terms |
| Required quotations | 11 of 23 tested purchases; $102,543 lacked required quotes | Later sewer records identify original competitive bid prices and quotations for added work |
| Procurement policy | Professional-service guidance was inadequate | Policy amended in 2019 and renewed in 2022 |

The historical audit figures and later control examples are not equivalent datasets. This scorecard therefore states procedural improvement and does not claim a zero-dollar post-audit noncompetitive-spending total.

## Sources

- New York State Office of the State Comptroller, [2018 Village audit](https://www.osc.ny.gov/files/local-government/audits/pdf/lgsa-audit-village-2018-tuxedo-park.pdf).
- New York State Office of the State Comptroller, [2022 Fiscal Stress Monitoring System Municipal Summary](https://www.osc.ny.gov/files/local-government/fiscal-monitoring/2022/pdf/2022-munis-summary.pdf).
- S&P Global Ratings, [Village general-obligation rating summary, July 27, 2021](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/news/ratingsdirect_summarytuxedoparkvillagenewyorkgeneralobligation_48859941_jul-27-2021_0.pdf).
- Village of Tuxedo Park, [Fiscal Health of the Village Has Never Been Better, May 10, 2023](https://www.tuxedopark-ny.gov/home/news/fiscal-health-village-has-never-been-better).
- New York State Office of the State Comptroller, [Property Tax Cap for Villages](https://www.osc.ny.gov/files/local-government/academy/pdf/property-tax-cap-for-villages-04-07-2022.pdf).
- New York State Office of the State Comptroller, [Constitutional Debt Limit Guidance](https://www.osc.ny.gov/local-government/resources/constitutional-debt-limit).
- Village of Tuxedo Park, [March 3, 2025 Board record](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2025-03-03_bot_rescheduled_feb_19_meeting_0.pdf).
- Village of Tuxedo Park, [March 10, 2025 water-bond resolution](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2025-03-10_bot_special_meeting.pdf).
