# Exhibit A: 2007 BST Forensic Findings and Control Reforms

**Prepared for:** Memorandum to the Village Board of Tuxedo Park  
**Source record:** BST forensic report dated May 9, 2007

## Executive finding

The BST report documented serious Police Department financial-control failures and credited Mayor David C. McFadden and Trustee Christopher Hansen with helping develop and implement anti-fraud and internal-control measures. BST stated that those measures appeared to have ameliorated the identified problems.

## Findings and response

| Topic | BST finding or calculation | Administrative significance |
|---|---:|---|
| Questionable or unsupported payments | Approximately $150,000 | Established the need for a forensic review and stronger controls |
| Services not rendered or goods not received or missing | At least $50,253 | Identified a documented subset of the broader questioned amount |
| Police personal-service costs | Approximately $282,477 above the historical trend over the four fiscal years ending May 31, 2006 | Showed the scale of the payroll and staffing-control problem |
| Requisition review | Trustee review of requisitions over $5,000 | Added governing-body oversight before payment |
| Invoice control | Departmental invoice tracking and QuickBooks recording | Improved transaction documentation |
| Budget control | Budget-variance review and written Board directives | Improved monitoring and accountability |
| Payroll control | Closer review of police payroll and hours | Addressed the largest recurring operating-cost risk |

## Board-memo significance

The report supports a matter-of-fact statement that the 2005–2007 McFadden/Hansen administration confronted documented Police Department control failures and implemented corrective measures. It does not support attributing every questioned amount to a final adjudication of wrongdoing by a particular person.

## Source

- BST, forensic report to the Village of Tuxedo Park, May 9, 2007. A copy of the report is included with this exhibit package.
