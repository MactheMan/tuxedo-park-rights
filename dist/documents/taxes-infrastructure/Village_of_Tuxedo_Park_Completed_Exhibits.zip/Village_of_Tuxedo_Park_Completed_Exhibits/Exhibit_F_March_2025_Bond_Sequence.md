# Exhibit F: March 2025 Bond Sequence

**Prepared for:** Memorandum to the Village Board of Tuxedo Park

## Vote and authorization chronology

| Date | Action | Amount | Result |
|---|---|---:|---|
| March 3, 2025 | Pond No. 3 bridge replacement authorization | Up to $250,000 | Adopted by the successor Board |
| March 3, 2025 | Sewer-system improvements authorization | Up to $650,000 | Adopted by the successor Board |
| March 3, 2025 | Water-system improvements authorization | Up to $4,500,000 | Received three affirmative votes; Trustee Paul Brooke abstained and Trustee Charles Turner was absent; required supermajority was not obtained |
| March 10, 2025 | Water-system improvements reconsidered | Up to $4,500,000 | New serial-bond resolution adopted with a 40-year period of probable usefulness |

## Financial interpretation

The three named authorizations total $5.4 million. They were decisions of the successor Board in March 2025. They were not expenditures made by the McFadden administration.

| Term | Meaning |
|---|---|
| Authorization | Legal authority to issue debt up to a stated ceiling |
| Issuance | Bonds or notes actually sold or otherwise placed |
| Contracting | A contract or purchase commitment entered for the project |
| Expenditure | Money actually paid or accrued for completed work, goods, or services |

A bond resolution does not, by itself, establish that the entire authorized amount was issued, contracted, or spent. It also does not establish the project’s final cost.

## Sources

- Village of Tuxedo Park, [March 3, 2025 Board record](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2025-03-03_bot_rescheduled_feb_19_meeting_0.pdf).
- Village of Tuxedo Park, [March 10, 2025 Special Meeting and Water-System Bond Resolution](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2025-03-10_bot_special_meeting.pdf).
