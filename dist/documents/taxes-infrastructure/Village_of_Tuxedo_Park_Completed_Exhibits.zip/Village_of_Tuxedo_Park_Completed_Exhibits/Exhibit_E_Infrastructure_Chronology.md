# Exhibit E: Infrastructure Chronology by Administration

**Prepared for:** Memorandum to the Village Board of Tuxedo Park

## Attribution standard

Each row identifies the documented project phase. Initiation, authorization, financing, design, management, and later continuation are treated as distinct actions.

## Chronology

| Administration and period | Project or action | Amount | Description and attribution |
|---|---|---:|---|
| McFadden/Hansen, 2005–2007 | Police Department control reforms | Not a capital amount | BST credited McFadden and Hansen with corrective anti-fraud and internal-control measures |
| Guinchard–Guazzoni, April 2015 | Causeway Wall settlement BAN | $135,000 | Pre-July 2017 financing |
| Guinchard–Guazzoni, May 2015 | DPW loader financing | $104,000 | Five-year equipment financing |
| Guinchard–Guazzoni, December 2015 | Police vehicle financing | $38,626 | Five-year vehicle financing |
| Guinchard–Guazzoni, April 19, 2017 | Club House and Continental Road reconstruction | $300,000 | Fifteen-year bond authorization before McFadden mayoralty |
| Guinchard–Guazzoni, April 19, 2017 | Water distribution and dam-related work | $606,000 | Thirty-year authorization before McFadden mayoralty |
| Guinchard–Guazzoni, April 19, 2017 | Wee-Wah Dam rehabilitation | Up to $2,970,000 | Planned, designed, permitted, bid, awarded, and financed before July 2017 |
| Transition, June 22, 2017 | Wee-Wah Dam, roads, and water financing closing | Approximately $3.65 million | Closing occurred before McFadden became Mayor |
| McFadden, July 2017–2023 | Inherited Wee-Wah Dam project | Existing financed project | Administration managed the inherited construction and later operating deficiencies |
| McFadden, 2017–2023 | Trunk-sewer investigation | Approximately $49,520 against $91,600 budget | Completed approximately $42,080 below budget |
| McFadden, 2017–2023 | SSES sewer rehabilitation | $531,750 estimate; grant up to $132,938 | Work completed in six road areas; remaining capacity directed to Pond No. 3-area trunk repairs |
| McFadden, 2017–2023 | Tuxedo Lake water-main replacement | Amount not stated in this exhibit | Design of critical aging main nearing completion and moving toward permitting |
| McFadden, 2017–2023 | Mountain Road-area water-main replacement | Amount not stated in this exhibit | Field investigation and design advanced |
| McFadden, 2017–2023 | Water Treatment Plant compliance and clearwell work | Amount not stated in this exhibit | Regulatory and engineering response advanced |
| McFadden, 2017–2023 | Pressure monitoring and district metering | Amount not stated in this exhibit | Operational controls initiated to identify pressure problems and water loss |
| McFadden, 2017–2023 | Dam inspections | Amount not stated in this exhibit | October 2022 reports issued for Tuxedo Lake, Pond No. 3, and Wee-Wah |
| McFadden, October 2021 | DPW Freightliner and hydraulic spreader | $148,031 | Five-year tax-exempt lease purchase |
| McFadden, October 2021 | Police interceptor | $47,895 | Five-year tax-exempt lease purchase |
| Citrin, March 3, 2025 | Pond No. 3 bridge replacement | Up to $250,000 | Successor-Board authorization |
| Citrin, March 3, 2025 | Sewer-system improvements | Up to $650,000 | Successor-Board authorization |
| Citrin, March 3, 2025 | Water-system improvements | Up to $4,500,000 | Three ayes, Trustee Paul Brooke abstained, and one trustee was absent; authorization did not pass |
| Citrin, March 10, 2025 | Water-system improvements reconsidered | Up to $4,500,000 | Successor Board adopted a new serial-bond authorization with a 40-year period of probable usefulness |

## Wee-Wah Dam award and inherited responsibility

While serving as Trustee, David McFadden voted against awarding the low bid for the Wee-Wah Dam project because, according to his firsthand account, the company had never built a dam before. The project’s planning, financing, bidding, and award preceded his July 2017 mayoralty. His administration inherited responsibility for managing the project and later deficiencies. The 2022 engineering record described the dam as generally sound while identifying valve-shaft, stop-log, and operating concerns under temporary control and long-term engineering consultation.

## Sources

- Joseph Zongol, [Capital & Infrastructure Project Status Update, December 14, 2022](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/news/20221214_bot_ws_project_update_memo_0.pdf).
- Village of Tuxedo Park, [March 3, 2025 Board record](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2025-03-03_bot_rescheduled_feb_19_meeting_0.pdf).
- Village of Tuxedo Park, [March 10, 2025 water-bond resolution](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2025-03-10_bot_special_meeting.pdf).
- BST forensic report, May 9, 2007, included in this package.
