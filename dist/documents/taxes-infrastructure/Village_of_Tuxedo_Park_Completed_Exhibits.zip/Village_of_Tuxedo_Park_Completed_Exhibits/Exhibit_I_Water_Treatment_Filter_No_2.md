# Exhibit I: Water Treatment Plant Filter No. 2 Reliability Response

**Prepared for:** Memorandum to the Village Board of Tuxedo Park  
**Period:** December 2022–January 2023  
**Administration:** Mayor David C. McFadden

## Executive finding

Village records document abnormal operation in the Water Treatment Plant filtration process and identify Filter No. 2 as the affected unit. DPW found a blown control-panel fuse, returned Filter No. 2 to service, and coordinated with VRI and Westech to resolve the issue without a quoted $5,700 Westech site visit.

An Orange County engineering study describes the plant as using two updraft dual-media filters. Restoring Filter No. 2 therefore restored the second filtration unit. Mayor McFadden’s firsthand account is that the response was urgent because failure of the remaining operating unit could have interrupted the Village’s ability to produce potable water. The public reports establish the problem, repair, return to service, and avoided visit; the continuity-risk statement remains attributed to McFadden.

## Chronology

| Date or period | Documented event | Result |
|---|---|---|
| December 14, 2022 | Water Treatment Plant filtering process was not operating normally | Village personnel met with VRI representatives, Jeff Voss, and John Bello |
| December 2022 | Westech quoted a one-day on-site troubleshooting visit, transportation, and lodging | Quoted cost of $5,700 |
| December 20, 2022–January 17, 2023 | DPW found a blown fuse in the control panel and put Filter No. 2 back in service | Second filtration unit restored |
| January 2023 | Coordinated calls with Tom Dennis of Westech, Jeff Voss, and Tyler Post resolved the Filter No. 2 issue | $5,700 site visit avoided |
| Plant configuration | Facility uses a flocculation tank, two updraft dual-media filters, and a clearwell | Confirms Filter No. 2 was one of two filtration units |

## Precision statement

The records support saying that Filter No. 2 was returned to service after DPW found a blown control-panel fuse and that a quoted $5,700 site visit was avoided. They do not state that the entire filter was replaced. The potable-water continuity risk is presented as Mayor McFadden’s firsthand assessment.

## Sources

- Village of Tuxedo Park, [December 2022 Construction Report](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/events/december_2022_construction_report.pdf).
- Village of Tuxedo Park, [January 2023 Construction Report](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/events/january_2023_construction_report.pdf).
- Village of Tuxedo Park, [DPW Report, December 20, 2022–January 17, 2023](http://www.tpfyi.com/docs/reports_-_dpw.pdf).
- Orange County, [Regional Ground-Water Study, treatment-facility description](https://www.orangecountygov.com/DocumentCenter/View/24401/Tuxedo-Report-PDF).
