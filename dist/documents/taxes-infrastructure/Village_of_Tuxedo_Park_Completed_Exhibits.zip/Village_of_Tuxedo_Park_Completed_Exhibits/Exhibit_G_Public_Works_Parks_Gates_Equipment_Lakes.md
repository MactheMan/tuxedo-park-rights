# Exhibit G: Public Works, Parks, Gates, Equipment, Utilities, and Lake Management

**Prepared for:** Memorandum to the Village Board of Tuxedo Park

## Evidence standard

This exhibit distinguishes public-record support from David C. McFadden’s firsthand statements. An attributed firsthand statement is included as such and is not presented as an independently audited figure.

## Accomplishment register

| Project or measure | Description | Evidence basis |
|---|---|---|
| Group mailbox stands | DPW built standardized group mailbox stands in-house, including a Continental Road installation and site landscaping | Village reports and purchase records |
| Village-owned traffic triangles | Leftover granite blocks from the Wee-Wah Dam project were repurposed for repairs to Village-owned traffic triangles | McFadden firsthand statement; no avoided-cost amount stated |
| Multi-skilled DPW staffing | Administration recruited workers with complementary carpentry, stone-masonry, plumbing, electrical, mechanical, and general-construction skills and used qualified staff for appropriate in-house work | McFadden firsthand statement; monthly Village reports corroborate varied in-house work |
| Equipment and supply inventory | Administration inventoried DPW and Police vehicles, equipment, and supplies and used the baseline to guide current and future purchases | McFadden firsthand statement |
| Surplus-equipment auction | Unusable or surplus DPW equipment was offered through Auctions International; $8,545 was received from 10 of 11 items by April 2022 | Official Village surplus list and Construction Report |
| Use of auction proceeds | Sale proceeds were reused for needed DPW and Police equipment purchases | McFadden firsthand statement |
| Wee-Wah Park | Administration improved the beach and shoreline, trees and landscaping, grills, picnic tables, dog-waste facilities, storage, and welcome or security facilities | Village reports, financial records, and McFadden firsthand statement |
| Village identity signs | Added signs for the Front Gate, Village Office, and Wee-Wah Park and Beach Club; McFadden designed the signs and DPW assisted with installation | Village posting and ledger entries; design and location details attributed to McFadden |
| SafePassage gate access | Implemented automatic gate access using license-plate recognition for registered users | Village implementation record |
| Replacement Main Gate traffic booth | Replaced the booth with protective construction, security glazing, reinforced foundation work, and vehicle-impact protection | Village project records and McFadden firsthand statement |
| Front Gate restoration | Repainted the original iron gate, restored its lanterns, opened views to August Brook, and improved the adjacent landscape and retaining-wall area during the 2020–2023 term | Official Village gatehouse announcement |
| Police civilian-vehicle parking | A 2005 rule required officers’ civilian vehicles to park behind the Police Station or Lodge rather than in front of the Keep, leaving the front area for police cruisers | Archived 2016 Board account describing the existing 2005 rule |
| Contractor use of South Gate | Contractors were permitted to exit through the South Gate to reduce the recurring Main Gate queue | McFadden firsthand statement |
| O&R project staging | Village property at or near the DPW facility was rented for overnight storage of trucks supporting the approximately three-year grid upgrade | McFadden firsthand statement; O&R independently documents the multi-year project |
| O&R vegetation coordination | Village worked with O&R on trees and branches overhanging electrical lines | McFadden firsthand statement; O&R documents trimming and danger-tree removal |
| Electric reliability | McFadden observed a major decrease in blackouts during his administration following the grid work and vegetation coordination | Expressly identified as McFadden’s observation |
| Eurasian watermilfoil | Administration authorized and permitted ProcellaCOR treatment in all three Village lakes; Village later stated that treatment reduced EWM populations in all three | Official Village statement |
| Nuisance geese | Administration used goose-management measures, including egg oiling according to McFadden, to reduce goose waste | Official nuisance-geese plan and McFadden firsthand statement |

## Lake-management comparison

| Measure | McFadden-era record | Later record | Supported conclusion |
|---|---|---|---|
| Eurasian watermilfoil control | ProcellaCOR treatment authorized and permitted in all three lakes; Village later reported reduced EWM populations | March 20, 2024 authorization for diver harvesting with a $20,055 base price and $3,200 per additional day | The earlier treatment has a documented Village statement of reduction; later diver pricing is documented |
| Comparative effectiveness | McFadden states the chemical treatment was inexpensive and effective compared with later diving | Later outcome report was not part of the record used for this exhibit | Comparative judgment remains expressly McFadden’s observation |
| Nuisance-geese management | Management plan documented; McFadden reports a substantial reduction in goose waste | No later comparison made in this exhibit | Achievement is stated with its evidence classification |

## Sources

- Village of Tuxedo Park, [Mayor Announces Gatehouse Operations, August 12, 2021](https://www.tuxedopark-ny.gov/home/news/mayor-announces-gatehouse-operations).
- Tuxedo Park FYI, [October 1, 2016 Board meeting archive](https://tpfyi.com/bot-archives-2016.html).
- Village of Tuxedo Park, [January 12, 2022 identity-signage archive](https://www.tuxedopark-ny.gov/news/1?page=12).
- Village of Tuxedo Park, [General Fund activity detail including Wee-Wah Park signs](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/events/reports_-_treasurer_-_mcr_wee_wah.pdf).
- Village of Tuxedo Park, [December 2021 surplus-equipment recommendation](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/events/7j._1-12_consent_agenda_-_dpw_items_-_declare_surplus.pdf).
- Village of Tuxedo Park, [April 2022 Construction Report](http://www.tpfyi.com/docs/aaconstruction_report.pdf).
- Orange & Rockland, [Tuxedo Park Reconductoring Phases I and II](https://www.oru.com/en/our-energy-future/our-energy-projects/upgrading-our-infrastructure).
- Orange & Rockland, [Phase II Tuxedo Park reliability project](https://www.oru.com/en/about-us/media-center/news/2021/04-13/oru-phase-ii-of-tuxedo-park-project-to-improve-electric-reliability).
- Village of Tuxedo Park, [Eurasian Watermilfoil Treatment](https://www.tuxedopark-ny.gov/home/news/invasive-aquatic-plant-eurasian-watermilfoil-treatment).
- Village of Tuxedo Park, [March 20, 2024 Board minutes](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/pages/2024-03-20_bot_0.pdf).
- Village of Tuxedo Park, [2022 Nuisance Geese Management Plan](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/events/tuxedo_report_nuisance_geese_plan_-_s._toth.pdf).
