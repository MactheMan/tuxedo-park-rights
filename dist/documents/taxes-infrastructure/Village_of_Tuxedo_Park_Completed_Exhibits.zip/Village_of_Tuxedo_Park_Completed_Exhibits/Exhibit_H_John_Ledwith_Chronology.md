# Exhibit H: John Ledwith, Deputy Clerk/Treasurer, Chronology

**Prepared for:** Memorandum to the Village Board of Tuxedo Park

## Executive finding

The official record reviewed for this exhibit did not substantiate the accusations of financial wrongdoing that preceded John Ledwith’s April 2017 firing. OSC reported that its audit “did not disclose significant findings with respect to the Village Clerk/Treasurer’s activities,” while separately finding that the function lacked adequate segregation of duties. The Village’s October 16, 2018 response stated that “no instances of misappropriation or serious misconduct were discovered during the lengthy and in-depth investigative process.”

In ordinary language, those findings clear Mr. Ledwith’s record of the alleged misappropriation or serious misconduct. For documentary precision, OSC did not name Mr. Ledwith or use the terms “cleared,” “exonerated,” or “vindicated.”

## Documented chronology

| Date | Event | What the record establishes |
|---|---|---|
| January 1, 2015–May 17, 2017 | Principal OSC audit period | Covered the Clerk/Treasurer function and ended before McFadden became Mayor in July 2017 |
| April 2017 | John Ledwith, then Deputy Clerk/Treasurer, was fired | OSC states that the Deputy Clerk/Treasurer was fired in April 2017 |
| September 13, 2017 | Board authorized a consulting agreement with Mr. Ledwith | The published court decision quotes the Board resolution |
| September 2017 | McFadden administration brought Mr. Ledwith back to Village service | Agreement covered building-inspection, code-enforcement, and water-related responsibilities |
| January 19, 2018 | Claudio Guazzoni and Robert Zgonena commenced litigation | Defendants included the Village, David McFadden as Mayor, and John Ledwith as a necessary party; plaintiffs challenged the agreement and sought personal repayment by McFadden |
| June 12, 2018 | Supreme Court decided the dismissal motion | Court dismissed Claudio Guazzoni for lack of capacity and standing, declined to dismiss the remaining claims at that stage, and made no finding that Mr. Ledwith committed financial wrongdoing |
| October 16, 2018 | Village response to OSC | Response stated that no misappropriation or serious misconduct was discovered |
| November 2018 | OSC issued Report 2018M-114 | Audit disclosed no significant findings regarding Clerk/Treasurer activities but identified a structural segregation-of-duties risk |

## Litigation qualification

David McFadden’s best recollection is that the remaining matter was later dropped or dismissed and was not resolved through a negotiated settlement. Because the published June 12, 2018 decision does not establish the later disposition, this exhibit does not assign a formal procedural term to it.

## Board-ready statement

> The prior Board fired John Ledwith, then Deputy Clerk/Treasurer, in April 2017. After I became Mayor, the Board authorized an agreement that brought him back to Village service. The State Comptroller subsequently reported that its audit did not disclose significant findings concerning the Clerk/Treasurer activities examined, and the Village’s formal response stated that no misappropriation or serious misconduct was discovered. That official review did not substantiate the accusations of financial wrongdoing that preceded Mr. Ledwith’s firing and supports my decision to bring him back. OSC also identified a serious segregation-of-duties weakness that required corrective oversight.

## Sources

- New York State Office of the State Comptroller, [Village of Tuxedo Park: Selected Financial Operations, Report 2018M-114](https://www.osc.ny.gov/files/local-government/audits/pdf/lgsa-audit-village-2018-tuxedo-park.pdf).
- New York Supreme Court, Orange County, [Guazzoni and Zgonena v. Village of Tuxedo Park, David McFadden, Mayor, and John Ledwith, June 12, 2018](https://caselaw.findlaw.com/court/ny-supreme-court/1897885.html), Index No. EF000551-2018.
