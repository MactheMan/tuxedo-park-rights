# Exhibit J: Certified Water and Sewer Plant Management

**Prepared for:** Memorandum to the Village Board of Tuxedo Park  
**Administration:** Mayor David C. McFadden

## Executive finding

The McFadden administration addressed the need for reliable certified operation of the Village’s water and sewer plants by considering outside operating firms and retaining VRI Environmental Services. The Board unanimously hired VRI to manage both plants beginning June 1, 2022. The Village announcement states that VRI supplied trained and certified facility managers, operators, mechanics, and technicians, maintained a physical day-to-day presence, and coordinated with government agencies.

Mayor McFadden states that the Village previously lacked sufficient in-house certified personnel for reliable operation of both plants, that multiple outside firms were interviewed, and that the new arrangement brought regulatory notices to the Board more promptly, reduced exposure to avoidable fines, and improved the technical information available for repair decisions. Those operational-history statements are presented as his firsthand account.

## Chronology and evidence

| Date or period | Event | Significance |
|---|---|---|
| Spring 2022 | Administration considered outside plant-operating firms | Comparative selection process described by McFadden |
| May 18, 2022 | Board agenda listed discussion of hiring VRI following the prior month’s executive session | Formal Board consideration documented |
| May 31, 2022 | Village announced unanimous hiring of VRI Environmental Services to manage both plants | Firm, scope, and Board action documented |
| June 1, 2022 | VRI service began | Effective date documented |
| Beginning June 2022 | VRI supplied certified managers, operators, mechanics, and technicians; maintained daily presence; interfaced with agencies | Operating and compliance structure documented |
| 2022 reporting year | Village water system reported compliance with applicable operating, monitoring, and reporting requirements and no violation of a maximum contaminant level or other water-quality standard | Contemporaneous compliance result; not presented as proof of sole causation |
| December 2022–January 2023 | VRI participated in troubleshooting Filter No. 2 with DPW and Westech | Demonstrates technical coordination under the operating model |

## Board-memo significance

The documented record supports the statement that the McFadden administration professionalized plant operations through certified outside management, an on-site presence, maintenance capability, and agency coordination. The statements about prior notification delays, avoided fines, and the interview process remain expressly attributed to Mayor McFadden.

## Sources

- [May 18, 2022 Board agenda](http://www.tpfyi.com/docs/BOT%20agenda_1_1.pdf).
- Village of Tuxedo Park, [VRI Environmental Services announcement, May 31, 2022](https://www.tuxedopark-ny.gov/home/news/vri-environmental-services-inc).
- Village of Tuxedo Park, [2022 Annual Water Quality Report](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/news/annual_water_quality_report_2022.pdf).
- Village of Tuxedo Park, [December 2022 Construction Report](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/events/december_2022_construction_report.pdf).
