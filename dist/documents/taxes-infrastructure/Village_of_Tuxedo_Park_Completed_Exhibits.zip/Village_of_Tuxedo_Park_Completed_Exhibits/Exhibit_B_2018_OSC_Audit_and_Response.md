# Exhibit B: 2018 OSC Audit and Village Response

**Prepared for:** Memorandum to the Village Board of Tuxedo Park  
**Audit:** New York State Office of the State Comptroller Report 2018M-114

## Scope and chronology

OSC’s principal audit period was January 1, 2015 through May 17, 2017. Its professional-services review extended through December 2017. The principal period therefore ended before David C. McFadden became Mayor in July 2017, while the professional-services testing crossed the transition.

## Audited findings

| Area | OSC finding | Amount or population |
|---|---|---:|
| Professional-service competition | Competition was not solicited for 14 of 15 professional-service providers | $926,188 paid |
| Written professional agreements | Five providers lacked written agreements | $169,330 paid |
| Required quotations | 11 of 23 tested purchases lacked required quotations | $102,543 |
| Clerk/Treasurer controls | Incompatible duties created the ability to execute and conceal transactions without detection | Structural control finding |
| Water billing | Rate documentation and billing controls were inadequate | 494 inaccurate bills identified |
| Information technology | Policies, recovery planning, filtering, and security training required improvement | Control finding |

The dollar figures above describe different audit findings and are not additive.

## Clerk/Treasurer language

OSC stated:

> “Although our audit did not disclose significant findings with respect to the Village Clerk/Treasurer’s activities, the Village Clerk/Treasurer had the ability to easily execute and conceal transactions without detection.”

The Village’s October 16, 2018 response stated:

> “Additionally, and more importantly, we are pleased that no instances of misappropriation or serious misconduct were discovered during the lengthy and in-depth investigative process.”

The two statements should be read together. The audit did not disclose significant findings in the activities examined, but it did identify an unacceptable segregation-of-duties risk.

## Recommendation crosswalk

| OSC recommendation | Documented response or later record | Supported assessment |
|---|---|---|
| Segregate incompatible duties or add compensating review | Village committed to additional review; later procedures required specified advance-paid claims to return for Board audit | Corrective review documented |
| Solicit and document competition for professional services | Village response described interviews and proposal review for the attorney and engineers | Competitive-selection process described |
| Use written professional agreements | Later engineering records contain written scopes, fee schedules, amendments, and acceptance terms | Written-contract discipline documented |
| Obtain required written quotations | Later sewer records identify original bid prices and quotations for added work | Project-level quotation practice documented |
| Clarify water and capital-improvement rates | Public rate information was later available | Public documentation improved |
| Review rates used for quarterly billing | No conclusion stated in this exhibit | Not used as an achievement claim |
| Resolve prior overbillings and underbillings | No conclusion stated in this exhibit | Not used as an achievement claim |
| Adopt disaster-recovery, breach-notification, and acceptable-use policies | No conclusion stated in this exhibit | Not used as an achievement claim |
| Install web filtering and review Internet use | No conclusion stated in this exhibit | Not used as an achievement claim |
| Provide annual IT-security awareness training | No conclusion stated in this exhibit | Not used as an achievement claim |

## Procurement comparison

The $926,188 figure is an audited historical population. The later record consists of policy changes and documented examples, not a second audit using the same sampling method. The defensible conclusion is that procurement policy, written scopes, proposal review, bids, and quotations improved. This exhibit does not claim that later noncompetitive spending was zero.

## Source

- New York State Office of the State Comptroller, [Village of Tuxedo Park: Selected Financial Operations, Report 2018M-114](https://www.osc.ny.gov/files/local-government/audits/pdf/lgsa-audit-village-2018-tuxedo-park.pdf).
