# Exhibit C: December 14, 2022 Zongol Capital Program

**Prepared for:** Memorandum to the Village Board of Tuxedo Park  
**Engineer:** Joseph “Joe” Zongol, Weston & Sampson  
**Record:** Capital & Infrastructure Project Status Update, December 14, 2022

## Executive finding

The Village Engineer’s contemporaneous year-end memorandum documented an active and coordinated infrastructure program before the end of the McFadden administration. It recorded nine work streams involving dam safety, sewer rehabilitation, water-main replacement, treatment-plant compliance, pressure monitoring, district metering, and stormwater mapping.

## Project-status map

| Project track | Status recorded in December 2022 | Significance at transition |
|---|---|---|
| Dam safety | Inspections completed for Tuxedo Lake, Pond No. 3, and Wee-Wah; dams generally sound; Wee-Wah operating deficiencies under temporary control and long-term consultation | Condition assessments and follow-up work were active |
| Trunk-sewer investigation | Investigation completed for approximately $49,520 against a $91,600 budget | Approximately $42,080, or about 46%, below the investigation budget |
| SSES sewer rehabilitation | Work completed in six road areas; EFC grant and financing used; remaining capacity directed to Pond No. 3-area trunk repairs | Demonstrates construction progress, outside funding, and productive use of remaining capacity |
| Tuxedo Lake water main | Nearly 80-year-old critical main; design nearing completion and moving toward Department of Health permitting | Project was advancing toward construction readiness |
| Mountain Road-area water mains | Scope included Mountain Road, Schoolhouse Road, Schoolhouse Lane, Circle Drive, and Spartan Place; field investigation underway | Established an active design pipeline |
| Water Treatment Plant | Response to Health Department concerns submitted; clearwell modifications and plant-capacity adjustment proposed | Regulatory and engineering response underway |
| Pressure monitoring | Recording gauge selected for the Town pressure-reducing-valve station | Operational investigation aimed at pressure spikes and main breaks |
| District metering | Water-used-versus-water-billed analysis underway in the Mountain Farm, Camp Comfort, and Ivy Road area | Water-loss control initiative underway |
| Stormwater mapping | DPW and Weston & Sampson planned system mapping over the following six to twelve months | Asset-data foundation established for drainage and green-infrastructure planning |

## Attribution

The memorandum shows that the McFadden administration identified, investigated, designed, funded, or advanced these projects. It does not transfer authorship of later bond resolutions, contracts, change orders, or expenditures to the earlier administration. Later boards remained responsible for their own financing and execution decisions.

## Sources

- Joseph Zongol, [Capital & Infrastructure Project Status Update, December 14, 2022](https://www.tuxedopark-ny.gov/sites/g/files/vyhlif6941/f/news/20221214_bot_ws_project_update_memo_0.pdf).
- Village of Tuxedo Park, [Capital Infrastructure Projects Year-End Update](https://www.tuxedopark-ny.gov/home/news/capital-infrastructure-projects-year-end-update).
